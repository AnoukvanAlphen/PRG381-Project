package dash.model;

public enum StatusType {
     AVALIABLE, BOOKED
}
